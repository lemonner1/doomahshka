#include "functions.h"
#include <stdio.h>
#include <stdlib.h>

int prime(int* s_) 
{
	int flag = 0;
	int m = s_;

	for (int i = 2; i <= m / 2; ++i) 
	{
		if (m % i == 0) 
		{
			flag = 1;
			break;
		}
	}

	return flag;
}

int searching_simple_counts()
{
	int count = 2;
	int m = 0;

	while(m < 10001)
	{
		int l = prime(count);

		if (l == 0)
		{
			m++;
		}
		count++;
	}
	return count-1;
}
