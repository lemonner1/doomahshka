#pragma once

int searching_simple_counts();