#include "functions.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("%d", searching_simple_counts());
	return 0;
}